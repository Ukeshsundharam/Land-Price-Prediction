from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

# Load models and encoders
sqft_model = joblib.load('sqft_model.pkl')
price_model = joblib.load('price_model.pkl')
le_area = joblib.load('le_area.pkl')
le_built = joblib.load('le_built.pkl')

@app.route('/', methods=['GET', 'POST'])
def index():
    predicted_sqft = None
    predicted_price = None

    if request.method == 'POST':
        area = request.form['area']
        n_bedroom = int(request.form['n_bedroom'])
        buildtype = request.form['buildtype']

        # Encode area and build type
        area_enc = le_area.transform([area])[0]
        build_enc = le_built.transform([buildtype])[0]

        # Predict INT_SQFT
        predicted_sqft = sqft_model.predict([[area_enc, n_bedroom, build_enc]])[0]

        # Predict SALES_PRICE
        predicted_price = price_model.predict([[predicted_sqft, area_enc, n_bedroom, build_enc]])[0]

    return render_template('index.html', predicted_sqft=predicted_sqft, predicted_price=predicted_price)

if __name__ == '__main__':
    app.run(debug=True)
